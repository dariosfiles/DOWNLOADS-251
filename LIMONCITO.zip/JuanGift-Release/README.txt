Pls run this in a VM 😭😭
It will not ruin your pc but shit annoying
(tho if you are going to prank your friend, do it.)

THIS DISABLES TASK MANAGER!!!